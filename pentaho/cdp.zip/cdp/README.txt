
Enhanced version of the EIS-plugin, that includes:
   - write access to databases
   - full sql parameterization
   - Clojure support 
   - chaining/cascading of stages in SQL and clojure
   - Java-support (to be included)

